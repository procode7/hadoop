export SPARK_MAJOR_VERSION=2

spark-submit --repositories http://repo.hortonworks.com/content/groups/public/,http://repo1.maven.org/maven2/ resolution1.py

echo "Code Success1"

export SPARK_MAJOR_VERSION=2

spark-submit --repositories http://repo.hortonworks.com/content/groups/public/,http://repo1.maven.org/maven2/ resolution2.py

echo "Code Success2"

export SPARK_MAJOR_VERSION=2

spark-submit --repositories http://repo.hortonworks.com/content/groups/public/,http://repo1.maven.org/maven2/ resolution3.py

echo "Code Success3"




