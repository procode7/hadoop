import pyspark as ps
from pyspark.sql import HiveContext
from pyspark.sql import SQLContext
from pyspark import SparkConf, SparkContext
import pyspark.sql.functions as F
from pyspark.sql import HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import DataType

sc=ps.SparkContext()
hive_context = HiveContext(sc)
sqlContext = SQLContext(sc)

df = sqlContext.read.csv("hdfs://sandbox-hdp.hortonworks.com:/retailligence/store2/S2_grievances_4-19-18_trial.csv",header=True,mode="DROPMALFORMED")

dataframe = df.filter(F.col("Timestamp").between('2015-05-31',current_date()))  ##to check
#dataframe=df.filter(F.col("Timestamp").between(current_date(),date_add(current_date(),30)))

df_monthly_resolution=dataframe.\
                groupby(month("Timestamp").alias("month"),year('Timestamp').alias('year'),'Grievance_severity').\
                agg(mean("Duration").alias("Avearge Days of Resolution"))
df_monthly_resolution=df_monthly_resolution.orderBy('year','month','Grievance_severity')
df_monthly_resolution=df_monthly_resolution.withColumnRenamed('Grievance_Severity','Query_type')
df_monthly_resolution=df_monthly_resolution.withColumnRenamed('Avearge Days of Resolution','Average_Days_of_Resolution')


final_df = df_monthly_resolution.withColumn("StoreId", lit(2))
final_df.show()
hive_context.sql("use default")
final_df.write.mode("append").insertInto("average_days_of_resolution")

