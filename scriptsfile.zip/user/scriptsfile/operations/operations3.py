import pyspark as ps
from pyspark.sql import HiveContext
from pyspark.sql import SQLContext
from pyspark import SparkConf, SparkContext
import pyspark.sql.functions as F
from pyspark.sql import HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import DataType

sc=ps.SparkContext()
hive_context = HiveContext(sc)
sqlContext = SQLContext(sc)


df = sqlContext.read.csv("/retailligence/store3/Store3_Revenue&Gross_Margin.csv",header=True,mode="DROPMALFORMED")
df_2 = sqlContext.read.csv("/retailligence/store3/Operations_data_part1_Store3.csv",header=True,mode="DROPMALFORMED")



dataframe = df.filter(F.col("Timestamp").between('2015-05-01',current_date()))
dataframe_2 = df_2.filter(F.col("Timestamp").between('2015-05-01',current_date()))


#dataframe = df.filter(F.col("Timestamp").between(current_date(),date_add(current_date(),30)))
#dataframe_2 = df_2.filter(F.col("Timestamp").between(current_date(),date_add(current_date(),30)))

df_rev_monthly=dataframe.orderBy('Timestamp')\
                                .groupBy(month("Timestamp").alias("month"),year('Timestamp').alias('year'))\
                                .agg(sum("revenue").alias("Revenue"))
df_rev_monthly=df_rev_monthly.orderBy('year','month')


#
df_op_monthly=dataframe_2.orderBy('Timestamp').groupBy(month("Timestamp").alias("month"),year('Timestamp').alias('year')).\
                        agg(sum("Operation_cost").alias("Operational_cost_m"),sum("payroll").alias("Payroll_m"),\
                            sum("Insurance").alias("Insurance_m"),sum("Lease_Rent").alias("Lease_Rent_m"),\
                            sum("Repair_and_Maintenance").alias("Repair_and_Maintenance_m"),\
                            sum("Security_and_Fire").alias("Security_and_Fire_m"),\
                            sum("Utilities").alias("Utilities_m"))
df_op_monthly=df_op_monthly.orderBy('year','month')


df_op_monthly=df_op_monthly.withColumnRenamed('month','month_1').withColumnRenamed('year','year_1')

df_op_monthly.registerTempTable('df_op_monthly_t')

df_rev_monthly.registerTempTable('df_rev_monthly_t')

final = hive_context.sql("select * FROM df_op_monthly_t a INNER JOIN df_rev_monthly_t b ON a.month_1 = b.month and a.year_1 = b.year")

final=final.withColumn("Operationalcost_per_Revenue", (F.col("Operational_Cost_m") / F.col("Revenue"))).\
            withColumn("Payroll_per_Revenue", (F.col("Payroll_m") / F.col("Revenue"))).\
            withColumn("Insurance_per_Revenue", (F.col("Insurance_m") / F.col("Revenue"))).\
            withColumn("Lease_Rent_per_Revenue", (F.col("Lease_Rent_m") / F.col("Revenue"))).\
	    withColumn("Repair_and_Maintenance_per_Revenue", (F.col("Repair_and_Maintenance_m") / F.col("Revenue"))).\
            withColumn("Security_and_Fire_per_Revenue", (F.col("Security_and_Fire_m") / F.col("Revenue"))).\
            withColumn("Utilities_per_Revenue", (F.col("Utilities_m") / F.col("Revenue"))).\
            drop('month_1','year_1')
final.orderBy('year','month')
final_df = final.withColumn("StoreId", lit(3))
final_df.show()
hive_context.sql("use default")
#final_df.write.saveAsTable("operation_effectiveness")

final_df.write.mode("append").insertInto("operation_effectiveness")


