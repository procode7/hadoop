import pyspark as ps
from pyspark.sql import HiveContext
from pyspark.sql import SQLContext
from pyspark import SparkConf, SparkContext
import pyspark.sql.functions as F
from pyspark.sql import HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import DataType
sc = ps.SparkContext() 
hive_context = HiveContext(sc)
sqlContext = SQLContext(sc)

hive_context.sql("use default")
hive_context.sql('DROP TABLE IF EXISTS operation_effectiveness')
