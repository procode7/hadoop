export SPARK_MAJOR_VERSION=2

spark-submit --repositories http://repo.hortonworks.com/content/groups/public/,http://repo1.maven.org/maven2/ operations1.py

echo "Code Success1"

spark-submit --repositories http://repo.hortonworks.com/content/groups/public/,http://repo1.maven.org/maven2/ operations2.py

echo "Code Success2"

spark-submit --repositories http://repo.hortonworks.com/content/groups/public/,http://repo1.maven.org/maven2/ operations3.py

echo "Code Success3"
