#! #!/usr/bin/env python

from pyspark import SparkConf, SparkContext
import pyspark.sql.functions as F
from pyspark.sql import HiveContext
from pyspark.sql.functions import *
from pyspark.sql.types import DataType
import pyspark as ps
from pyspark.sql import SQLContext

sc=ps.SparkContext()
hive_context = HiveContext(sc)
sqlContext = SQLContext(sc)


df_2 = sqlContext.read.csv("/retailligence/store1/Revenue_Categorywise_Monthly_S1.csv",header=True,mode="DROPMALFORMED")
df = sqlContext.read.csv("/retailligence/store1/S1_staff_allocation_4-20-18_modified.csv",header=True,mode="DROPMALFORMED")


## to check


dataframe = df.filter(F.col("Timestamp").between(current_date(),date_add(current_date(),30)))
dataframe_2 = df_2.filter(F.col("Timestamp").between(current_date(),date_add(current_date(),30)))


df_monthly_staff=dataframe.groupby(month('Timestamp').alias('month'),year('Timestamp').alias('year'),'category').agg(sum("num_staff").alias("Staffs"))

df_monthly_staff=df_monthly_staff.orderBy('year','month','category')
df_monthly_staff.show()

df_revcat_monthly=dataframe_2.groupby(month('Timestamp').alias('month'),year('Timestamp').alias('year'),'Category').agg(sum("Monetary").alias("Revenue"))


df_revcat_monthly=df_revcat_monthly.orderBy('year','month','Category')
df_revcat_monthly.show()

df_monthly_staff=df_monthly_staff.withColumnRenamed('month','month_1').withColumnRenamed('year','year_1')
df_monthly_staff.show()

df_monthly_staff.registerTempTable('df_monthly_staff_t')
df_revcat_monthly.registerTempTable('df_revcat_monthly_t')
final = sqlContext.sql("select * FROM df_monthly_staff_t a INNER JOIN df_revcat_monthly_t b ON a.month_1 = b.month and a.year_1 = b.year and a.category = b.Category")
final.show()

final=final.withColumn("Revenue_per_Staff", (F.col("Revenue") / F.col("Staffs"))).\
            drop('month_1','year_1,category')
final.orderBy('year','month')
final.show()
final_df = final.withColumn("StoreId", lit(1))
final_df.show()
hive_context.sql("use default")
final_df.write.saveAsTable("staff_effectiveness")


############################################### store 2 ################################################



df_2 = sqlContext.read.csv("/retailligence/store2/Revenue_Categorywise_Monthly_S2.csv",header=True,mode="DROPMALFORMED")
df = sqlContext.read.csv("/retailligence/store2/S2_staff_allocation_4-20-18_modified.csv",header=True,mode="DROPMALFORMED")


## to check
dataframe = df.filter(F.col("Timestamp").between(current_date(),date_add(current_date(),30)))
dataframe_2 = df_2.filter(F.col("Timestamp").between(current_date(),date_add(current_date(),30)))


df_monthly_staff=dataframe.groupby(month('Timestamp').alias('month'),year('Timestamp').alias('year'),'category').agg(sum("num_staff").alias("Staffs"))

df_monthly_staff=df_monthly_staff.orderBy('year','month','category')
df_monthly_staff.show()

df_revcat_monthly=dataframe_2.groupby(month('Timestamp').alias('month'),year('Timestamp').alias('year'),'Category').agg(sum("Monetary").alias("Revenue"))


df_revcat_monthly=df_revcat_monthly.orderBy('year','month','Category')
df_revcat_monthly.show()

df_monthly_staff=df_monthly_staff.withColumnRenamed('month','month_1').withColumnRenamed('year','year_1')
df_monthly_staff.show()


df_monthly_staff.registerTempTable('df_monthly_staff_t')
df_revcat_monthly.registerTempTable('df_revcat_monthly_t')
final = sqlContext.sql("select * FROM df_monthly_staff_t a INNER JOIN df_revcat_monthly_t b ON a.month_1 = b.month and a.year_1 = b.year and a.category = b.Category")


final=final.withColumn("Revenue_per_Staff", (F.col("Revenue") / F.col("Staffs"))).\
            drop('month_1','year_1,category')
final.orderBy('year','month')
final.show()
final_df = final.withColumn("StoreId", lit(2))
final_df.show()
hive_context.sql("use default")
#final_df.write.saveAsTable("staff_effectiveness")

final_df.write.mode("append").insertInto("staff_effectiveness")


################################################ store 3 #########################################

df_2 = sqlContext.read.csv("/retailligence/store3/Revenue_Categorywise_Monthly_S3.csv",header=True,mode="DROPMALFORMED")
df = sqlContext.read.csv("/retailligence/store3/S3_staff_allocation_4-20-18_modified.csv",header=True,mode="DROPMALFORMED")


## to check
dataframe = df.filter(F.col("Timestamp").between(current_date(),date_add(current_date(),30)))
dataframe_2 = df_2.filter(F.col("Timestamp").between(current_date(),date_add(current_date(),30)))


df_monthly_staff=dataframe.groupby(month('Timestamp').alias('month'),year('Timestamp').alias('year'),'category').agg(sum("num_staff").alias("Staffs"))

df_monthly_staff=df_monthly_staff.orderBy('year','month','category')
df_monthly_staff.show()

df_revcat_monthly=dataframe_2.groupby(month('Timestamp').alias('month'),year('Timestamp').alias('year'),'Category').agg(sum("Monetary").alias("Revenue"))


df_revcat_monthly=df_revcat_monthly.orderBy('year','month','Category')
df_revcat_monthly.show()

df_monthly_staff=df_monthly_staff.withColumnRenamed('month','month_1').withColumnRenamed('year','year_1')
df_monthly_staff.show()


df_monthly_staff.registerTempTable('df_monthly_staff_t')
df_revcat_monthly.registerTempTable('df_revcat_monthly_t')
final = sqlContext.sql("select * FROM df_monthly_staff_t a INNER JOIN df_revcat_monthly_t b ON a.month_1 = b.month and a.year_1 = b.year and a.category = b.Category")
final.show()

final=final.withColumn("Revenue_per_Staff", (F.col("Revenue") / F.col("Staffs"))).\
            drop('month_1','year_1,category')
final.orderBy('year','month')

final_df = final.withColumn("StoreId", lit(3))
final_df.show()
hive_context.sql("use default")
#final_df.write.saveAsTable("staff_effectiveness")

final_df.write.mode("append").insertInto("staff_effectiveness")
