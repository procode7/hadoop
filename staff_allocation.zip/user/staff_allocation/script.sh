export SPARK_MAJOR_VERSION=2

spark-submit --repositories http://repo.hortonworks.com/content/groups/public/,http://repo1.maven.org/maven2/ ./staff.py

echo "code success"
